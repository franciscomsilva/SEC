#!/usr/bin/bash

java -cp ../lib/UserProtocolContract-1.0.jar:../lib/HAContract-1.0.jar:target/HDLT-1.0-SNAPSHOT-jar-with-dependencies.jar HDLT_Server

