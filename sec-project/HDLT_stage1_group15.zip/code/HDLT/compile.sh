#!/usr/bin/bash

unset JAVA_HOME
../../maven/bin/mvn package